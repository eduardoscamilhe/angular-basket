export class User {

    constructor(public username: string, public name: string,
        public image: string, public email: string, public roles: any[], public token: string) {


    }
}